# pdf-decryptor
Small console application to decrypt pdf files

# Usage

```
.\PdfDecryptor.exe encrypted_input.pdf decrypted_output_path.pdf pwd1 pwd2
```
# Requirements
.net 4.x
no installation required

# Source code
http://git.inoa.com.br/brokertools/pdf-decryptor
